package com.numx.game;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import java.util.Random;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(10, 17, 36);
    private final int panel = Color.rgb(22, 32, 58);
    private final int accent = Color.rgb(94, 234, 212);
    private final int white = Color.rgb(244, 247, 255);
    private final int muted = Color.rgb(166, 180, 207);
    private int answer, attempts = 0, score = 0, best = 0;
    private TextView hint, attemptsView, scoreView, bestView, numberView;
    private EditText input;
    private Button guessButton, restartButton;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("numx_records", MODE_PRIVATE);
        best = prefs.getInt("best_attempts", 0);
        score = prefs.getInt("total_score", 0);
        newRound();
        buildUi();
        updateStats();
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = label("NUM-X", 30, accent, true);
        root.addView(brand);
        TextView subtitle = label("THE NUMBER CHALLENGE", 12, muted, true);
        LinearLayout.LayoutParams subp = params(-2, -2);
        subp.topMargin = dp(3);
        root.addView(subtitle, subp);

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setGravity(Gravity.CENTER);
        hero.setPadding(dp(18), dp(24), dp(18), dp(24));
        hero.setBackground(rounded(panel, dp(24)));
        LinearLayout.LayoutParams hp = params(-1, -2);
        hp.topMargin = dp(26);
        root.addView(hero, hp);

        TextView eyebrow = label("I'M THINKING OF A NUMBER", 12, muted, true);
        hero.addView(eyebrow);
        numberView = label("1 — 100", 36, white, true);
        LinearLayout.LayoutParams np = params(-2, -2);
        np.topMargin = dp(10);
        hero.addView(numberView, np);
        TextView instruction = label("Can you crack the code?", 15, muted, false);
        LinearLayout.LayoutParams ip = params(-2, -2);
        ip.topMargin = dp(8);
        hero.addView(instruction, ip);

        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams stp = params(-1, -2);
        stp.topMargin = dp(16);
        root.addView(stats, stp);
        attemptsView = statCard(stats, "ATTEMPTS", "0");
        scoreView = statCard(stats, "TOTAL SCORE", "0");
        bestView = statCard(stats, "BEST ROUND", "—");

        TextView prompt = label("YOUR GUESS", 12, muted, true);
        LinearLayout.LayoutParams pp = params(-2, -2);
        pp.topMargin = dp(24);
        root.addView(prompt, pp);

        input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setTextColor(white);
        input.setHintTextColor(muted);
        input.setHint("Enter a number from 1 to 100");
        input.setTextSize(16);
        input.setPadding(dp(16), dp(13), dp(16), dp(13));
        input.setBackground(rounded(panel, dp(14)));
        LinearLayout.LayoutParams inp = params(-1, -2);
        inp.topMargin = dp(9);
        root.addView(input, inp);

        guessButton = new Button(this);
        guessButton.setText("CHECK MY GUESS  →");
        guessButton.setTextColor(bg);
        guessButton.setTextSize(14);
        guessButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        guessButton.setAllCaps(false);
        guessButton.setBackground(rounded(accent, dp(14)));
        LinearLayout.LayoutParams bp = params(-1, dp(54));
        bp.topMargin = dp(12);
        root.addView(guessButton, bp);
        guessButton.setOnClickListener(v -> checkGuess());

        hint = label("Tip: every guess gets you closer.", 14, muted, false);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tip = params(-1, -2);
        tip.topMargin = dp(16);
        root.addView(hint, tip);

        restartButton = new Button(this);
        restartButton.setText("PLAY AGAIN");
        restartButton.setTextColor(white);
        restartButton.setTextSize(14);
        restartButton.setAllCaps(false);
        restartButton.setBackground(rounded(Color.rgb(43, 56, 87), dp(14)));
        LinearLayout.LayoutParams rp = params(-1, dp(50));
        rp.topMargin = dp(18);
        root.addView(restartButton, rp);
        restartButton.setOnClickListener(v -> {
            newRound();
            input.setText("");
            input.setEnabled(true);
            guessButton.setEnabled(true);
            hint.setText("New round started. Make your first guess!");
            hint.setTextColor(muted);
            updateStats();
        });

        TextView footer = label("Think smart. Guess sharp. NUM-X.", 12, muted, false);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = params(-1, -2);
        fp.topMargin = dp(22);
        root.addView(footer, fp);
    }

    private TextView statCard(LinearLayout row, String title, String value) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(5), dp(13), dp(5), dp(13));
        card.setBackground(rounded(panel, dp(15)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(78), 1);
        cp.setMargins(dp(3), 0, dp(3), 0);
        row.addView(card, cp);
        TextView v = label(value, 22, white, true);
        card.addView(v);
        TextView t = label(title, 9, muted, true);
        LinearLayout.LayoutParams tp = params(-2, -2);
        tp.topMargin = dp(5);
        card.addView(t, tp);
        return v;
    }

    private void checkGuess() {
        String raw = input.getText().toString().trim();
        if (raw.isEmpty()) {
            input.setError("Enter a number first");
            return;
        }
        int guess;
        try { guess = Integer.parseInt(raw); }
        catch (NumberFormatException e) { input.setError("Enter a valid number"); return; }
        if (guess < 1 || guess > 100) {
            input.setError("Choose from 1 to 100");
            return;
        }
        attempts++;
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(input.getWindowToken(), 0);
        if (guess < answer) {
            hint.setText("TOO LOW  ↑   Try a higher number.");
            hint.setTextColor(Color.rgb(251, 191, 36));
        } else if (guess > answer) {
            hint.setText("TOO HIGH  ↓   Try a lower number.");
            hint.setTextColor(Color.rgb(251, 146, 60));
        } else {
            int roundPoints = Math.max(10, 110 - attempts * 10);
            score += roundPoints;
            if (best == 0 || attempts < best) best = attempts;
            prefs.edit().putInt("best_attempts", best).putInt("total_score", score).apply();
            hint.setText("🎉 CORRECT! It was " + answer + ". +" + roundPoints + " points!");
            hint.setTextColor(accent);
            input.setEnabled(false);
            guessButton.setEnabled(false);
            guessButton.setText("ROUND COMPLETE");
        }
        updateStats();
    }

    private void newRound() {
        answer = new Random().nextInt(100) + 1;
        attempts = 0;
    }

    private void updateStats() {
        if (attemptsView != null) attemptsView.setText(String.valueOf(attempts));
        if (scoreView != null) scoreView.setText(String.valueOf(score));
        if (bestView != null) bestView.setText(best == 0 ? "—" : best + " tries");
        if (numberView != null) numberView.setText("1 — 100");
        if (guessButton != null && guessButton.isEnabled()) guessButton.setText("CHECK MY GUESS  →");
    }

    private LinearLayout.LayoutParams params(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
