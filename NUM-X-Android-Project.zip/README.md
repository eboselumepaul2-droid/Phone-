# NUM-X Android

A modern Android number-guessing game. Guess a number from 1 to 100, use high/low hints, earn points for fewer attempts, and keep a best-round record on the device.

## Build
The GitHub Actions workflow can build a debug APK using Java 17, Gradle 8.9, and Android Gradle Plugin 8.7.3.
